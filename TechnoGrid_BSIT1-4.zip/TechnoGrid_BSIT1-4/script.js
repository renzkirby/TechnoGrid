function openNav(){
    document.getElementById("hamburgerPanel").style.width = "250px";
}
function closeNav(){
    document.getElementById("hamburgerPanel").style.width = "0";
}
function dropDown(){
    document.getElementById("myDropdown").classList.toggle("show");
}
function dropCart(){
    document.getElementById("cartDropdown").classList.toggle("show");
}
// Close the dropdown if the user clicks outside of it
window.onclick = function(event){
    if(!event.target.matches('.fa-user')){
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for(i = 0; i < dropdowns.length; i++){
            var openDropdown = dropdowns[i];
            if(openDropdown.classList.contains('show')){
                openDropdown.classList.remove('show');
            }
        }
    }
    if (!event.target.matches('.fa-cart-shopping')) {
        var dropdowns = document.getElementsByClassName("cart-content");
        var i;
    }
}

// Star Rating style
const stars = document.querySelectorAll(".stars i");

stars.forEach((star, index1) => {
    star.addEventListener("click", () => {
        stars.forEach((star, index2) => {
            index1 >= index2 ? star.classList.add("active") : star.classList.remove("active");
        });
    });
});

