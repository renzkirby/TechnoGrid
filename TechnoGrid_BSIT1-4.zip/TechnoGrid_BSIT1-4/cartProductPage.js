let productsList = document.querySelector('.cart-list');
let productsQuantity = document.querySelector('.product-quantity');
let total = document.querySelector('.total');
let quantity = document.querySelector('.product-quantity')

function closeCart(){
    document.getElementById("cartDropdown").classList.remove("show");
}
function checkOut(){
    alert("Proceeding to checkout...");
    productLists = [];
    reloadCart();
}

let productLists = [];
let products = [];

// Get all the products from the html 
let productItems = document.querySelectorAll('.product-page');
productItems.forEach((item) => {
    let product = {
        name: item.querySelector('.product-name').innerText,
        image: item.querySelector('img').src,
        price: parseInt(item.querySelector('.product-price').innerText.replace('₱', '').replace(',', '')),
    };
    products.push(product);
});

// Add action to cart buttons
productItems.forEach((item, key) => {
    let addToCartButton = item.querySelector('.product-add')
    addToCartButton.addEventListener('click', () => {
        alert("Added to cart");
        addToCart(key);
    });
});

function addToCart(key) {
    if(productLists[key] == null){
        productLists[key] = JSON.parse(JSON.stringify(products[key]));
        productLists[key].quantity = 1;
    } else {
        productLists[key].quantity++;
    }
    reloadCart();
}

function reloadCart(){
    productsList.innerHTML = '';
    let count = 0;
    let totalPrice = 0;
    productLists.forEach((value, key) => {
        totalPrice = totalPrice + value.price * value.quantity;
        count = count + value.quantity;
        if(value != null) {
            let newDiv = document.createElement('div');
            newDiv.classList.add('cart-row');
            newDiv.innerHTML = `
               <li class="cart-item">
                    <img src="${value.image}"/>
                    <p class="item-name">${value.name}</p>
                    <p class="item-price">₱${(value.price * value.quantity).toLocaleString()}</p>
                    <p class="item-quant">
                        <button class="change-quantity" onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                        <span class="product-quantity">${value.quantity}</span>
                        <button class="change-quantity" onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
                    </p>
                    <button class="remove-btn" type="button" onclick="removeItem(${key})">Remove</button>
                </li>`; 
            productsList.appendChild(newDiv);
        }
    })
    total.innerText = `₱${totalPrice.toLocaleString()}`;
    quantity.innerText = count;
}

function removeItem(key) {
    delete productLists[key];
    reloadCart();
}

function changeQuantity(key, quantity) {
    if(quantity == 0) {
        delete productLists[key];
    } else {
        productLists[key].quantity = quantity;
    }
    reloadCart();
}
