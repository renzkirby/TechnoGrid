document.addEventListener('DOMContentLoaded', function () {
    const registerForm = document.querySelector('.register-form');
    const loginForm = document.querySelector('.login-form');

    if (registerForm) {
        registerForm.addEventListener('submit', function (event) {
            event.preventDefault();
            const name = document.querySelector('.reg-name').value;
            const email = document.querySelector('.reg-email').value;
            const phoneNumber = document.querySelector('.reg-phone-number').value;
            const password = document.querySelector('.reg-password').value;

            let users = JSON.parse(localStorage.getItem('users')) || [];

            const userExists = users.some(user => user.email === email);

            if (userExists) {
                alert('User already exists with this email!');
            } else {
                const newUser = {
                    name: name,
                    email: email,
                    phoneNumber: phoneNumber,
                    password: password
                };

                users.push(newUser);
                localStorage.setItem('users', JSON.stringify(users));
                alert('Registration successful!');
                window.location.href = 'log in.html';
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', function (event) {
            event.preventDefault();
            const email = document.querySelector('.login-email').value;
            const password = document.querySelector('.login-password').value;

            let users = JSON.parse(localStorage.getItem('users')) || [];

            const user = users.find(user => user.email === email && user.password === password);

            if (user) {
                alert('Login successful!');
                window.location.href = 'index.html';
            } else {
                alert('Invalid email or password!');
            }
        });
    }
});
