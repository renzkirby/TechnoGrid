let slideIndex = 0;
carousel();
function carousel() {
    let i;
    let slides = document.getElementsByClassName("slideshow-img");
    for(i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if(slideIndex > slides.length) {
        slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "inline-block";
    setTimeout(carousel, 2000)
}