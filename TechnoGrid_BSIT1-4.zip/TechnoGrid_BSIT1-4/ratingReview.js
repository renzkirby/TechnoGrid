let ratings = {
    Average: 0,
    Total: 0
};

let reviews = [];

function createStarRating() {
    const starsContainer = document.getElementById('star-rating');
    starsContainer.innerHTML = '';
    for (let i = 1; i <= 5; i++) {
        const star = document.createElement('span');
        star.classList.add('star');
        star.innerHTML = '<i class="fa-solid fa-star"></i>';
        star.setAttribute('data-value', i);
        star.addEventListener('click', function () {
            const value = parseInt(this.getAttribute('data-value'));
            selectStars(value);
            ratings = submitRating(value);
            populateRatings();
        });
        starsContainer.appendChild(star);
    }
}

function selectStars(value) {
    const stars = document.querySelectorAll('.stars .star');
    stars.forEach((star, index) => {
        if (index < value) {
            star.classList.add('selected');
        }else {
            star.classList.remove('selected');
        }
    });
}

function submitRating(value) {
    ratings.Total++;
    ratings.Average = ((ratings.Average * (ratings.Total - 1)) + value) / ratings.Total;
    return ratings;
}

function submitReview() {
    const reviewText = document.getElementById('review-text').value.trim();
    if (reviewText === '') {
        alert('Please enter a review.');
        return;
    };

    const selectedStars = document.querySelectorAll('.stars .star.selected').length;
    const review = {
        User: 'User',
        Date: new Date().toLocaleDateString(),
        Text: reviewText,
        Rating: selectedStars
    };

    reviews.unshift(review);

    document.getElementById('review-text').value = '';

    populateReviews();
}

function populateRatings() {
    const starPercentage = (ratings.Average / 5) * 100;
    const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;
    const starsContainer = document.getElementById('star-rating');
    starsContainer.style.width = starPercentageRounded;

    const ratingCountElement = document.getElementById('rating-count');
    ratingCountElement.innerText = `Based on ${ratings.Total} rating(s)`;
}

function populateReviews() {
    const reviewList = document.getElementById('review-list');
    reviewList.innerHTML = ''; // Clear existing reviews

    reviews.forEach(review => {
        const li = document.createElement('li');
        li.classList.add('review-item');

        const starsHTML = getStarsHTML(review.Rating);
        li.innerHTML = `
        <p class="date">${review.Date}</p>
        <p class="user">${review.User}</p>
        <div class="stars">${starsHTML}</div>
        <p>${review.Text}</p>
    `;
        reviewList.appendChild(li);
    });
}

function getStarsHTML(rating) {
    let starsHTML = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            starsHTML += '<span class="star"><i class="fa-solid fa-star active"></i></span>'; // Full star
        } else {
            starsHTML += '<span class="star"><i class="fa-regular fa-star"></i></span>'; // Empty star
        }
    };
    return starsHTML;
}

function buyNow() {
    alert('Redirecting to checkout…');
}

function addToCart() {
    alert('Product added to cart!');
}

createStarRating();
populateRatings();
populateReviews();