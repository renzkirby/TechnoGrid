// search bar function
// search bar function
const productsSearch = document.querySelector(".products-search");
const searchInput = document.getElementById("input-box");

searchInput.onkeyup = function(){
    let result = [];
    let input = searchInput.value;
    if(input.length){
        result = availableKeywords.filter((keyword) => {
            return keyword.toLowerCase().includes(input.toLowerCase());
        });
        console.log(result);
    }
    display(result);

    if(!result.length){
        productsSearch.innerHTML = '';
    }
}

function display(result){
    const content = result.map((list) => {
        return "<li onclick=selectInput(this)>" + list + "</li>";
    });
    productsSearch.innerHTML = "<ul>" + content.join('') + "</ul>";
}

function selectInput(list){
    searchInput.value = list.innerHTML;
    productsSearch.innerHTML = '';
}


// 
document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.querySelector("[data-search]");
    const searchResultsContainer = document.querySelector(".products-search");
    const searchItemTemplate = document.getElementById("search-item-template");

    // Define your items with corresponding URLs
    const availableKeywords = [
        { name: "Phone", url: "./productsCategory/phones.html" },
        { name: "Flashdrive", url: "./productsCategory/flashDrives.html" },
        { name: "Speakers", url: "./productsCategory/speakers.html" },
        { name: "Mouse", url: "./productsCategory/mice.html" },
        { name: "Earphones", url: "./productsCategory/headEarPhones.html" },
        { name: "Powerbank", url: "./productsCategory/powerbanks.html" },
        { name: "Keyboard", url: "./productsCategory/keyboards.html" }
    ];

    searchInput.addEventListener("input", (e) => {
        const value = e.target.value.trim().toLowerCase();

        // Clear previous search results
        searchResultsContainer.innerHTML = '';

        availableKeywords.forEach(item => {
            const itemText = item.name.toLowerCase();
            if (itemText.includes(value)) {
                // Clone the template content and populate it with item data
                const templateContent = searchItemTemplate.content.cloneNode(true);
                const searchItemElement = templateContent.querySelector(".search-item");
                searchItemElement.textContent = item.name;
                searchItemElement.addEventListener("click", () => {
                    // Redirect to the corresponding URL when item is clicked
                    window.location.href = item.url;
                });
                searchResultsContainer.appendChild(templateContent);
            }
        });
    });
});
